# 317A1
# A README by fbl773	
Group: FLEX 007
		Devin Fortin
		Frank Lewis
		Sarah Vancuren


*All Code was written using Python3* 

How To run our code for the MNKY Problem.
-------------------------------------------

0) Be sure that you have Python 3 downloaded!

1) Download the zip file

2) if you are looking for our most operational code
	- type "./MNKYshow" into your commandline and a usage message will appear.

3) if you are looking to see the general state of testing for modules
	- type "./runTests" into your command line and a usage message will appear.

Files				Dependencies
---------			------------	
genTests.py			None
informedSearch.py	Problem, heapq, timeit
Search.py			Problem, collections, timeit
Problem.py			copy, math
runTests			Problem, Search, informedSearch, genTests
MNKYshow			Problem, Search, informedSearch,genTests

